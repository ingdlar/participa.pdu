<?php

namespace App\Http\Livewire\Form;

use Livewire\Component;

class Navigation extends Component
{
    public function render()
    {
        return view('livewire.form.navigation');
    }
}
