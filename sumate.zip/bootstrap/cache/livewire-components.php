<?php return array (
  'form.ins-form' => 'App\\Http\\Livewire\\Form\\InsForm',
  'form.navigation' => 'App\\Http\\Livewire\\Form\\Navigation',
  'form.partials.addr-info' => 'App\\Http\\Livewire\\Form\\Partials\\AddrInfo',
  'form.partials.comment-info' => 'App\\Http\\Livewire\\Form\\Partials\\CommentInfo',
  'form.partials.contact-info' => 'App\\Http\\Livewire\\Form\\Partials\\ContactInfo',
  'form.partials.education-info' => 'App\\Http\\Livewire\\Form\\Partials\\EducationInfo',
  'form.partials.interest-info' => 'App\\Http\\Livewire\\Form\\Partials\\InterestInfo',
  'form.partials.personal-info' => 'App\\Http\\Livewire\\Form\\Partials\\PersonalInfo',
  'dashboard.show-total' => 'App\\Http\\Livewire\\dashboard\\ShowTotal',
);