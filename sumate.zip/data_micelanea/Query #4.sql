
INSERT INTO core_electors(id,elector,note) VALUES (1,'Miembro','Establece que los miembros son los que elijen');
INSERT INTO core_electors(id,elector,note) VALUES (2,'Unidad','Establece que la unidad es la que elije.');
INSERT INTO core_electors(id,elector,note) VALUES (3,'Consejo','Establece que los consejos son quienes elijen.');
INSERT INTO core_electors(id,elector,note) VALUES (4,'Asamblea','Establece que la asamblea es la que elije.');

INSERT INTO core_units(id,unity,note) VALUES (1,'Ejecutiva','Unidad Ejecutiva');
INSERT INTO core_units(id,unity,note) VALUES (2,'Rectora','Unidad Rectora');
INSERT INTO core_units(id,unity,note) VALUES (3,'Electoral','Unidad Electoral');
INSERT INTO core_units(id,unity,note) VALUES (4,'Local','Unidad Local');
INSERT INTO core_units(id,unity,note) VALUES (5,'Política','Unidad Política');
INSERT INTO core_units(id,unity,note) VALUES (6,'Asamblea','Asamblea');
INSERT INTO core_units(id,unity,note) VALUES (7,'Consejo','Consejo');
INSERT INTO core_units(id,unity,note) VALUES (8,'Miembro','Miembro');

INSERT INTO core_elective_methods(id,method,note) VALUES (1,'Primaria','Establece que sera electo en uno de los tipos de primarias.');
INSERT INTO core_elective_methods(id,method,note) VALUES (2,'Primaria Cerrada','Establece que la primaria es el método de elección.');
INSERT INTO core_elective_methods(id,method,note) VALUES (3,'Primaria Abierta','Establece que la primaria cerrada es el método de elección.');
INSERT INTO core_elective_methods(id,method,note) VALUES (4,'Convención','Establece que la convención es el método de elección.');
INSERT INTO core_elective_methods(id,method,note) VALUES (5,'Organismo','Establece que el organismo es quien elije.');

INSERT INTO core_levels(id,level,note) VALUES (1,'Nacional','Aplica en todo el territorio Nacional.');
INSERT INTO core_levels(id,level,note) VALUES (2,'Provincial','Aplica  en el territorio de una Provincia.');
INSERT INTO core_levels(id,level,note) VALUES (3,'Municipal','Aplica en el territorio de un Municipio.');
INSERT INTO core_levels(id,level,note) VALUES (4,'Distrital','Aplica a nivel de un Distrito Municipal.');
INSERT INTO core_levels(id,level,note) VALUES (5,'Zonal','Aplica al nivel de una zona.');
INSERT INTO core_levels(id,level,note) VALUES (6,'Sectorial','Aplica a todo un sector.');
INSERT INTO core_levels(id,level,note) VALUES (7,'Local','Aplica al nivel de una Unidad Local.');
INSERT INTO core_levels(id,level,note) VALUES (8,'Ultramar','Aplica en el exterior.');
INSERT INTO core_levels(id,level,note) VALUES (9,'Circunscripción 1',NULL);
INSERT INTO core_levels(id,level,note) VALUES (10,'Circunscripción 2',NULL);
INSERT INTO core_levels(id,level,note) VALUES (11,'Circunscripción 3',NULL);
INSERT INTO core_levels(id,level,note) VALUES (12,'Circunscripción 4',NULL);

INSERT INTO core_durations(id,duration,type) VALUES (1,4,'y');
INSERT INTO core_durations(id,duration,type) VALUES (2,1,'y');
INSERT INTO core_durations(id,duration,type) VALUES (3,2,'y');

INSERT INTO core_boards(id,board,is_permanent) VALUES (1,'Secretaría Ejecutiva',1);
INSERT INTO core_boards(id,board,is_permanent) VALUES (2,'Comisión de Finanzas',1);
INSERT INTO core_boards(id,board,is_permanent) VALUES (3,'Comisión de Organización',1);
INSERT INTO core_boards(id,board,is_permanent) VALUES (4,'Comisión de Educación',1);
INSERT INTO core_boards(id,board,is_permanent) VALUES (5,'Comisión de Comunicación',1);
INSERT INTO core_boards(id,board,is_permanent) VALUES (6,'Comisión de Tecnología',1);
INSERT INTO core_boards(id,board,is_permanent) VALUES (7,'Comisión de Humanidad',1);
INSERT INTO core_boards(id,board,is_permanent) VALUES (8,'Comisión de Fiscalización',1);
INSERT INTO core_boards(id,board,is_permanent) VALUES (9,'Comisión de Ética y Disciplina',1);
INSERT INTO core_boards(id,board,is_permanent) VALUES (10,'Comision Electoral',1);
INSERT INTO core_boards(id,board,is_permanent) VALUES (11,'Comisión Estratégica Electoral',1);
INSERT INTO core_boards(id,board,is_permanent) VALUES (12,'Comicion de Deporte',0);
INSERT INTO core_boards(id,board,is_permanent) VALUES (13,'Comicion de Medio Ambiente',0);

INSERT INTO core_periods(id,start,end,note) VALUES (1,'2024/10/01','2028/10/01','Periodo Electoral Popular');

INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Presidente',1,0,1,1,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Senador',32,0,1,1,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Diputado',190,0,1,1,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Diputado Parlacen',NULL,0,1,1,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Sindico',NULL,0,1,1,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Regidor',NULL,0,1,1,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Director',NULL,0,1,1,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Vocal',NULL,0,1,1,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Secretario',NULL,1,1,4,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Tesorero',NULL,1,1,4,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Organizador',NULL,1,1,4,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Educador',NULL,1,1,4,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Corresponsal',NULL,1,1,4,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Director Tecnológico',NULL,1,1,4,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Humanista',NULL,1,1,4,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Procurador',NULL,1,1,4,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Director de Ética',NULL,1,1,4,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Elector',NULL,1,1,4,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Estratega',NULL,1,1,4,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Representante',NULL,1,3,5,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Consultor Juridico',NULL,1,2,5,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Delegado Electoral',NULL,1,2,5,1,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Asambleista',NULL,1,4,5,2,NULL);
INSERT INTO core_elective_positions(id,name,quantity,is_internal,elector_id,elective_method_id,duration_id,note) VALUES (NULL,'Politico',NULL,1,4,5,1,NULL);




