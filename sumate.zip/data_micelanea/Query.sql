
DROP SCHEMA IF EXISTS `pducore` ;
CREATE SCHEMA IF NOT EXISTS `pducore`  DEFAULT CHARACTER SET utf8 ;
USE `pducore` ;




