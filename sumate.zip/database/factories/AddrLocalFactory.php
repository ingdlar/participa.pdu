<?php

namespace Database\Factories;

use App\Models\AddrLocal;
use Illuminate\Database\Eloquent\Factories\Factory;

class AddrLocalFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    protected $model = AddrLocal::class;

    public function definition()
    {
        return [
            'user_id' => $this->faker->numberBetween(1, 50),
            'sector' => $this->faker->numberBetween(1, 1000),
            'residency' => $this->faker->name(),
            'street' => $this->faker->name(),
            'country_id' => $this->faker->numberBetween(1, 150),
            'state_id' => $this->faker->numberBetween(1, 32),
            'city_id' => $this->faker->numberBetween(1, 200),
        ];
    }
}
