<?php

namespace Database\Factories;

use App\Models\RegContact;
use Illuminate\Database\Eloquent\Factories\Factory;

class RegContactFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    protected $model = RegContact::class;

    public function definition()
    {
        return [
            'user_id' => $this->faker->numberBetween(1, 50),
            'type_id' => $this->faker->numberBetween(1,1),
            'contact' => $this->faker->numberBetween(8296851254, 8095861610),
        ];
    }
}
