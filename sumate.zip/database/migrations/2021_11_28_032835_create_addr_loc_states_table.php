<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAddrLocStatesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('addr_loc_states', function (Blueprint $table) {
            $table->id();
            $table->string('state', 200);
            $table->boolean('active')->nullable();
            $table->string('zone', 10)->nullable();
            $table->foreignId('country_id');

            //$table->foreign('country_id')->references('id')->on('addr_countries')->onUpdate('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('addr_loc_states');
    }
}
