<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAddrLocCitiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('addr_loc_cities', function (Blueprint $table) {
            $table->id();
            $table->string('city', 200);
            $table->boolean('active')->nullable();;
            $table->boolean('is_dm')->nullable();
            $table->foreignId('father_city_id')->nullable();
            $table->foreignId('state_id');

            $table->foreign('state_id')->references('id')->on('addr_loc_states')->onUpdate('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('addr_loc_cities');
    }
}
