<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAddrLocNeighborhoodsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('addr_loc_neighborhoods', function (Blueprint $table) {
            $table->id();
            $table->string('neighborhood', 200);
            $table->boolean('active')->nullable();
            $table->bigInteger('dm_id')->nullable();;
            $table->bigInteger('city_code')->nullable();;
            $table->foreignId('city_id');

            $table->foreign('city_id')->references('id')->on('addr_loc_cities')->onUpdate('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('addr_loc_neighborhoods');
    }
}
