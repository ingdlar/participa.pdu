<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAddrExtCitiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('addr_ext_cities', function (Blueprint $table) {
            $table->id();
            $table->string('city', 200);
            $table->foreignId('state_id')->nullable();
            $table->string('state_code', 10)->nullable();
            $table->foreignId('country_id')->nullable();
            $table->string('country_code', 10)->nullable();
            //$table->foreign('state_id')->references('id')->on('addr_ext_states');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('addr_ext_cities');
    }
}
