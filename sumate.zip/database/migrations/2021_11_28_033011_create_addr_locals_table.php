<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAddrLocalsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('addr_locals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id');
            $table->string('sector', 200)->nullable();
            $table->string('residency', 200)->nullable();
            $table->string('street', 200)->nullable();
            $table->string('nearby', 200)->nullable();
            $table->foreignId('country_id');
            $table->foreignId('state_id');
            $table->foreignId('city_id')->nullable();
            $table->foreignId('neighborhood_id')->nullable();
            $table->boolean('is_active')->default(1);
            $table->boolean('is_local')->nullable();
            $table->boolean('is_personal')->nullable();
            $table->foreign('user_id')->references('id')->on('users')->onUpdate('cascade')->onDelete('cascade');
            $table->foreign('country_id')->references('id')->on('addr_countries')->onUpdate('cascade');
            $table->foreign('state_id')->references('id')->on('addr_loc_states')->onUpdate('cascade');
            $table->foreign('city_id')->references('id')->on('addr_loc_cities')->onUpdate('cascade');
            $table->foreign('neighborhood_id')->references('id')->on('addr_loc_neighborhoods')->onUpdate('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('addr_locals');
    }
}
