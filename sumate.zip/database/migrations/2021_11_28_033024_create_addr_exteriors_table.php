<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAddrExteriorsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('addr_exteriors', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id');
            $table->string('sector', 200)->nullable();
            $table->string('residency', 200)->nullable();
            $table->string('street', 200)->nullable();
            $table->string('nearby', 200)->nullable();
            $table->foreignId('country_id');
            $table->foreignId('state_id')->nullable();
            $table->foreignId('city_id')->nullable();
            $table->foreignId('sector_id')->nullable();
            $table->boolean('is_active')->default(1);
            $table->boolean('is_local')->nullable();
            $table->boolean('is_personal')->nullable();
            $table->foreign('user_id')->references('id')->on('users')->onUpdate('cascade')->onDelete('cascade');
            $table->foreign('country_id')->references('id')->on('addr_countries')->onUpdate('cascade');
            $table->foreign('state_id')->references('id')->on('addr_ext_states')->onUpdate('cascade');
            $table->foreign('city_id')->references('id')->on('addr_ext_cities')->onUpdate('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('addr_exteriors');
    }
}
