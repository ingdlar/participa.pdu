<div>
    <div class="rounded-r-xl bg-white pt-4">
        <h5 class="pb-2 text-2xl antialiased font-bold text-center">Comparte tus Ideas, Opiniones, Conocimientos</h5>
        <div class="flex justify-center w-full pb-4">
            <textarea id="coment_id" name="comment" placeholder="Iquietudes, Ideas, Comentarios" rows="3" class="border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm w-11/12">
                {{ old('comment') }}
            </textarea>
        </div>
    </div>
</div>
