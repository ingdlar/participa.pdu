<div class="bg-gray-300 rounded-xl">
    <a href="<?php echo e(route('dashboard')); ?>" >
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" width="150">
    </a>
</div>
<?php /**PATH C:\laragon\www\sumate\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>