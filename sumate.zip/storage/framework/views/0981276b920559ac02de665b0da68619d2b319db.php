<div>
    <!-- Este formulario no esta utilizando las vista que esta en la carpeta livewire.
    Usa un solo componente de livewire para toda la vista-->

    <div class="mx-4 my-4">
    <form method="POST" action="<?php echo e(route('register')); ?>" class="space-y-4" name="insform">
        <?php echo csrf_field(); ?>

        <?php echo $__env->make('form.partials.membership', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('form.partials.personal-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('form.partials.contact-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('form.partials.addr-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('form.partials.education-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('form.partials.interest-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('form.partials.comment-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="flex justify-center py-3">
            <div>
                <?php if( $valid == 1 ): ?>
                    <script>
                        alert("Los datos son validos, presione Acceptar o Ok, luego enviar");
                    </script>
                    <div class="">
                        <label class="align-middle">
                            Datos Validados. Click en eviar.
                        </label>
                    </div>
                    <div class="flex justify-center">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['type' => 'submit','class' => 'bg-green-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'bg-green-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded']); ?>Enviar <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php elseif( sizeof($errors) > 1 ): ?>
                    <div>
                        <label class="align-middle">
                            Debe llenar todos los campos obligatorios.
                        </label>
                    </div>
                    <div class="flex justify-center ">
                        <button wire:click="register" type="button" class="bg-blue-700 hover:bg-blue-500 text-white font-bold py-2 px-4 rounded">Validar</button>
                    </div>
                <?php else: ?>
                    <div>
                        <label class="align-middle">
                            Haga clic para validar los datos.
                        </label>
                    </div>
                    <div class="flex justify-center">
                        <button wire:click="register" type="button" class="bg-green-600 hover:bg-gray-500 text-white font-bold py-2 px-4 rounded">Validar</button>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </form>

    </div>
</div>
<?php /**PATH C:\laragon\www\sumate\resources\views/livewire/form/ins-form.blade.php ENDPATH**/ ?>