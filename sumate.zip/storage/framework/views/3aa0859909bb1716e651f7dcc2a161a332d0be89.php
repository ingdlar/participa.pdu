<div>
    <div class="rounded-r-xl bg-white pt-4">
        <h1 class="text-2xl font-bold mx-4">Intereses o Aspiraciones</h1>
        <div class="grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 mx-8 pb-4">
            <div class="">
                <label for="elective_id" class=""><h6>Intereses Electivos Populares</h6></label>
                <select id="elective_id" name="elective" class="px-2 border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm w-11/12 h-10" >
                    <option value="">Elije...</option>
                    <?php $__currentLoopData = $electives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e(old('elective')==$eData->id  ? 'selected':''); ?> value="<?php echo e($eData->id); ?>" ><?php echo e($eData->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="">
                <label for="directive_id" class=""><h6>Posiciones Directivas Partidarias</h6></label>
                <select id="directive_id" name="directive" class="px-2 border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm w-11/12 h-10">
                    <option value="">Elije...</option>
                    <?php $__currentLoopData = $directives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e(old('directive')==$dData->id  ? 'selected':''); ?> value="<?php echo e($dData->id); ?>" ><?php echo e($dData->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="">
                <label for="social_id" class=""><h6>Principal Interes Social</h6></label>
                <select id="social_id" name="social" class="px-2 border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm w-11/12 h-10">
                    <option value="">Elije...</option>
                    <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e(old('social')==$sData->id ? 'selected':''); ?> value="<?php echo e($sData->id); ?>" ><?php echo e($sData->interest); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\sumate\resources\views/form/partials/interest-info.blade.php ENDPATH**/ ?>