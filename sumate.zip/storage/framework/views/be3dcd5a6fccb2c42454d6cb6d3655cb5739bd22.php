<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="flex justify-center p-4 bg-white mx-4 my-4 rounded-xl shadow-lg">
        <h1 class="text-xl font-bold text-gray-700">BIENVENIDO AL PARTIDO DOMINICANOS UNIDOS</h1>
    </div>
    <main class="bg-gray-200 rounded-r-xl shadow-xl mx-4 my-4">
        <h1>NOTICIAS</h1>
    </main>
    <main class=" bg-gray-200 rounded-r-xl shadow-xl mx-4 my-4">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard.show-total')->html();
} elseif ($_instance->childHasBeenRendered('SGZkTnX')) {
    $componentId = $_instance->getRenderedChildComponentId('SGZkTnX');
    $componentTag = $_instance->getRenderedChildComponentTagName('SGZkTnX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('SGZkTnX');
} else {
    $response = \Livewire\Livewire::mount('dashboard.show-total');
    $html = $response->html();
    $_instance->logRenderedChild('SGZkTnX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sumate\resources\views/dashboard.blade.php ENDPATH**/ ?>